#!/usr/bin/env bash

set -e
set -x

DINGDING_ROBOT_ADDR="https://oapi.dingtalk.com/robot/send?access_token=4dd14890111f3a23928531b1e1f290f1669ec227b813e68c3c7ee09dfb4000a9"
#设置当前脚本路径
UNITY3D_CURRENT_PATH=$(pwd)
#设置Unity3d项目目录
UNITY3D_PROJECT_PATH="/Users/lightpaw/Documents/Diablo-TE1"

#设置渠道标志
UNITY3D_CHANNEL="ENG"
#设置当前打包资源的路径
UNTIY3D_PACKAGE_RES_PATH="/Users/lightpaw/Documents/Diablo-res/ResPath/${UNITY3D_CHANNEL}"
#获取当前版本的地址
UNITY3D_PACKAGE_VERSION_PATH="${UNTIY3D_PACKAGE_RES_PATH}/Android/clientVersion.txt"
#设置打包时要读取资源地址
UNITY3D_READ_PATH="${UNITY3D_PROJECT_PATH}/Assets/ABConfig/ResPath.txt"
#编译日志文件
UNITY3D_BUILD_LOG_PATH="${UNITY3D_CURRENT_PATH}/buildLog.txt"

#设置Unity3d执行的编译方法
# UNITY3D_BUILD_METHOD="ABSourceDiabloTools.BuildAndroidResExtern"
#设置Unity3d exe文件路径
UNITY3D_EXE_PATH="/Applications/Unity/Unity.app/Contents/MacOS/Unity"

ZIP_COMMAND="zip -q -r -1 -D "

UNITY3D_BRANCH_NAME="releaseENG"

UNITY3D_BUILD_METHOD="ABSourceDiabloTools.BuildAndroidResExternPlugin"    

#国内的CDN路径
UNITY3D_IN_PATH="oss://game-d18-om/${UNITY3D_CHANNEL}"
#aws s3 cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/gzip/ s3://dev.lightpaw.cn/resources/Phi1/Android/HQ/1002/1/ --content-encoding gzip --recursive
#aws s3 cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/out/ s3://dev.lightpaw.cn/resources/Phi1/Android/HQ/1002/1/ --recursive
#aws s3 sync --delete /Users/kimiwang/Documents/ResPath/Phi1 s3://dev.lightpaw.cn/resources/Phi1 
#国内资源同步指令
UNITY3D_IN_SYNC_CMD="ossutilmac64 cp "
#aws --profile us s3 sync --delete /Users/kimiwang/Documents/ResPath/Phi1 s3://dev.lightpaw.com/resources/Phi1
#aws s3 --profile us cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/gzip/ s3://dev.lightpaw.com/resources/Phi1/Android/HQ/1002/1/ --content-encoding gzip --recursive
#aws s3 --profile us cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/out/ s3://dev.lightpaw.com/resources/Phi1/Android/HQ/1002/1/ --recursive
#国外的CDN路径
UNITY3D_OUT_PATH="oss://game-d18-om/${UNITY3D_CHANNEL}"
#国外资源同步指令
UNITY3D_OUT_SYNC_CMD="ossutilmac64 cp "

#生成gzip压缩的文件
UNITY3D_GZIP_FILE="gzip_big "
#设置版本初始值
cv=71
#设置资源初始值
rv=1
#设置起始版本
rv_init=1

if [ -f "${UNITY3D_PACKAGE_VERSION_PATH}" ]
then
	#读取之前打打包文件
	for cvs in `cat ${UNITY3D_PACKAGE_VERSION_PATH}`
	do
	  cv="$(cut -d'.' -f3 <<<"${cvs}")"
	  rv="$(cut -d'.' -f4 <<<"${cvs}")"
	  rv_init="$(cut -d'.' -f5 <<<"${cvs}")"
	done
fi


cd ${UNITY3D_PROJECT_PATH}

git reset --hard
git clean -df
git fetch
git checkout ${UNITY3D_BRANCH_NAME}
git fetch origin ${UNITY3D_BRANCH_NAME}
git reset --hard origin/${UNITY3D_BRANCH_NAME}
git submodule init
git submodule update
	
echo write ${UNTIY3D_PACKAGE_RES_PATH}
#将打包路径写入资源文件
echo -n ${UNTIY3D_PACKAGE_RES_PATH}>${UNITY3D_READ_PATH}

#git reset --hard
#git clean -f -d
#更新git版本
#git pull --rebase origin ${UNITY3D_BRANCH_NAME}

curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发ENG]新更新事件\",
					\"text\": \"###[开发]开始构建新的ENG资源版本,当前版本为${cv}.${rv} \n \"
				}
			}"
			
#获取当前hash
hash=$(git rev-parse HEAD)

# cd ${UNITY3D_PROJECT_PATH}/Tools
# chmod a+x ToLuacOSX.sh
# chmod a+x luac

# ./ToLuacOSX.sh
if [ ! -d ${UNTIY3D_PACKAGE_RES_PATH}/Android/Temp ]; 
then
#开始执行打包当前资源的方法
${UNITY3D_EXE_PATH} -quit -batchmode -nographics -nolog -executeMethod ${UNITY3D_BUILD_METHOD} -projectPath ${UNITY3D_PROJECT_PATH} -logFile -
fi
echo "Build Res Done"

UNITY_EXIT_CODE=$?

if [ $UNITY_EXIT_CODE -eq 0 ]; then
  echo "Run succeeded, no failures occurred";
else
  echo "Unexpected exit code $UNITY_EXIT_CODE";
  curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发ENG]新更新事件\",
					\"text\": \"###[开发ENG]构建失败 出现编译错误 代码[$UNITY_EXIT_CODE]\n \"
				}
			}"
	exit 0
fi



if [ -f "${UNITY3D_PACKAGE_VERSION_PATH}" ]
then
	echo "Version path exist"
else
	echo "[Error] Build Fail!!!!!!!!!"
	exit 0
fi

cv1=${cv}
rv1=$(expr ${rv} + 1)
echo "new version : ${cv1}.${rv1}"

#读取打包完成的文件
# for cvs in `cat ${UNITY3D_PACKAGE_VERSION_PATH}`
# do
# 	cv1="$(cut -d'.' -f3 <<<"${cvs}")"
# 	rv1="$(cut -d'.' -f4 <<<"${cvs}")"
# done

#判断版本号
if [[ "${cv1}" != "${cv}" ]]; then
	echo "[Error] cv[${cv} != cv1[${cv1}]]"
	curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发]新更新事件\",
					\"text\": \"###[开发ENG]构建失败 版本号出现异常变更\n \"
				}
			}"
	exit 0
fi

# if [ ! -d ${UNTIY3D_PACKAGE_RES_PATH}/Android/Temp ]; then
# 	echo "[Success] Nothing Change Build Done"
# 	curl ${DINGDING_ROBOT_ADDR} \
# 		-H 'Content-Type: application/json' \
# 		-d "{\"msgtype\": \"markdown\", 
# 			\"markdown\": {
# 				\"title\":\"[开发]新更新事件\",
# 					\"text\": \"###[开发]构建失败 没有需要更新的资源\n \"
# 				}
# 			}"
# 	exit 0
# fi

if [ ! -d ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1} ]; then
	echo "[Success] Nothing Change Build Done"
	curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发]新更新事件\",
					\"text\": \"###[开发ENG]构建失败 没有需要更新的资源\n \"
				}
			}"
	exit 0
fi

# ${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/ --prefix ${UNITY3D_IN_PATH}/Android/${rv1}/ --retry 99

# ${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1} ${UNITY3D_IN_PATH}/Android/${rv1}

# #cd ${UNTIY3D_PACKAGE_RES_PATH}/Android/HQ/${cv}/${rv1}
# #${UNITY3D_GZIP_FILE}

# # cd ${UNTIY3D_PACKAGE_RES_PATH}/Android/Temp

# for (( i = rv_init; i < rv1; i++ )); do
# 	cd ${UNTIY3D_PACKAGE_RES_PATH}/Android/Temp
# 	if [ ! -f "${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip" ]
# 	then
# 		#statements
# 		for (( j = i + 1; j <= rv1; j++ )); do
# 			#statements

# 			if [ ! -d "${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/${i}" ]
# 			then
# 				mkdir ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/${i}	
# 			fi	
			
# 			if [ -d ${j} ]
# 			then
# 				cp -r ${j} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/${i}
# 			fi
# 		done

# 		cd ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/${i}

# 		${ZIP_COMMAND} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip .

# 		size="$(du -k ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip)"

# 		echo -n ${size}>${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/info_${i}.txt

# 		rm -rf ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/${i}
# 	fi
# 	# ${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip --prefix ${UNITY3D_IN_PATH}/Android/${rv1}/ 
# 	# ${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/info_${i}.txt --prefix ${UNITY3D_IN_PATH}/Android/${rv1}/
# done

${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1} ${UNITY3D_IN_PATH}/Android/${rv1} --output-dir=/tmp/ -r -f

# for (( i = rv_init; i < rv1; i++ )); do
# 	if [ -f "${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip" ]
# 	then
# 		rm -r ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update_${i}.zip
# 	fi
# 	if [ -f "${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/info_${i}.zip" ]
# 	then
# 		rm -r ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/info_${i}.zip
# 	fi
# done

echo -n "DEV.AR.${cv1}.${rv1}.${rv_init}">${UNITY3D_PACKAGE_VERSION_PATH}
# rm -rf ${UNTIY3D_PACKAGE_RES_PATH}/Android/Temp


curl ${DINGDING_ROBOT_ADDR} \
   -H 'Content-Type: application/json' \
   -d "{\"msgtype\": \"markdown\", 
       \"markdown\": {
          \"title\":\"[开发ENG]新更新事件\",
            \"text\": \"###[开发ENG]热更版本 ${cv1}.${rv1}:创建成功 \n \"
        }
      }"

echo "[Success] New Version [${cv1}.${rv1}] Builded"
exit 0
