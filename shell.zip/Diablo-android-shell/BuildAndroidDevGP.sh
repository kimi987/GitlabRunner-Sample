#!/usr/bin/env bash

set -e
set -x

DINGDING_ROBOT_ADDR="https://oapi.dingtalk.com/robot/send?access_token=4dd14890111f3a23928531b1e1f290f1669ec227b813e68c3c7ee09dfb4000a9"
#设置当前脚本路径
UNITY3D_CURRENT_PATH=$(pwd)
#设置Unity3d项目目录
UNITY3D_PROJECT_PATH="/Users/lightpaw/Documents/Diablo-Dev"

#设置当前SDKTag的路径
UNITY3D_SDK_TAG_PATH="${UNITY3D_PROJECT_PATH}/Assets/Resources/sdkTag.bytes"
#设置当前ServerTag的路径
UNITY3D_SERVER_TAG_PATH="${UNITY3D_PROJECT_PATH}/Assets/Resources/serverTag.txt"

RES_PATH="/Users/lightpaw/Documents/Diablo-res/"
#设置当前打包资源的路径
UNTIY3D_PACKAGE_RES_PATH="${RES_PATH}ResPath/${UNITY3D_CHANNEL}"
#获取当前版本的地址
UNITY3D_PACKAGE_VERSION_PATH="${UNTIY3D_PACKAGE_RES_PATH}/Android/clientVersion.txt"

#获取当前安卓构建版本号地址
UNITY3D_BUNDLE_VERSION_PATH="${RES_PATH}VersionPath/${SDK}/bundleVersion.txt"

UNITY_CHANNEL_FILE_PATH="${UNITY3D_PROJECT_PATH}/Assets/ABConfig/ChannelFiles.txt"
#StreamAsset的地址
UNITY_STREAMASSET_PATH="${UNITY3D_PROJECT_PATH}/Assets/StreamingAssets"
#设置打包时要读取资源地址
UNITY3D_READ_PATH="${UNITY3D_PROJECT_PATH}/Assets/ABConfig/ResPath.txt"
#编译日志文件
UNITY3D_BUILD_LOG_PATH="${UNITY3D_CURRENT_PATH}/buildLog.txt"
#设置Unity3d执行的编译方法
UNITY3D_BUILD_METHOD="BuildSteps.BuildAndroidUpdateAuto"
#设置Unity3d exe文件路径
UNITY3D_EXE_PATH="/Applications/Unity2019.4.30/Unity.app/Contents/MacOS/Unity"

BUILD_SYMBOLS="CHANNEL_SOULBATTLE;SDKLOGIN_ENABLE"

BUNDLE_ID="com.lightpaw.godsquest.jrtt"

BUNDLE_VERSION="1"

GAME_NAME="神与旅途"
#设置当前的分支名
UNITY3D_BRANCH_NAME="develop1"

ZIP_COMMAND="zip -q -r -1 "

#国内的CDN路径
UNITY3D_IN_PATH="resources/${UNITY3D_CHANNEL}"
#aws s3 cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/gzip/ s3://dev.lightpaw.cn/resources/Phi1/Android/HQ/1002/1/ --content-encoding gzip --recursive
#aws s3 cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/out/ s3://dev.lightpaw.cn/resources/Phi1/Android/HQ/1002/1/ --recursive
#aws s3 sync --delete /Users/kimiwang/Documents/ResPath/Phi1 s3://dev.lightpaw.cn/resources/Phi1 
#国内资源同步指令
UNITY3D_IN_SYNC_CMD="ttgops-cli_mac uploadcdn --path "
#aws --profile us s3 sync --delete /Users/kimiwang/Documents/ResPath/Phi1 s3://dev.lightpaw.com/resources/Phi1
#aws s3 --profile us cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/gzip/ s3://dev.lightpaw.com/resources/Phi1/Android/HQ/1002/1/ --content-encoding gzip --recursive
#aws s3 --profile us cp /Users/kimiwang/Documents/ResPath/Phi1/Android/HQ/1002/1/out/ s3://dev.lightpaw.com/resources/Phi1/Android/HQ/1002/1/ --recursive
#国外的CDN路径
UNITY3D_OUT_PATH="resources/${UNITY3D_CHANNEL}"
#国外资源同步指令
UNITY3D_OUT_SYNC_CMD="ttgops-cli_mac uploadcdn"

UNITY_DOWNLOAD_LINK="https://lf3-ma17cdn-cn.dailygn.com/obj/light-game-cn/ma17/Android/Packages/"

#生成gzip压缩的文件
UNITY3D_GZIP_FILE="gzip_big "
#设置版本初始值
cv=10
#设置资源初始值
rv=1
#设置version初始值
mainVersion=0
mainSubVersion=1.0
mainVersionCode=1

SDKTag=7

cd ${UNITY3D_PROJECT_PATH}

git reset --hard
git fetch
git checkout ${UNITY3D_BRANCH_NAME}
git fetch origin ${UNITY3D_BRANCH_NAME}
git reset --hard origin/${UNITY3D_BRANCH_NAME}
rm -rf ${UNITY3D_PROJECT_PATH}/XLua
	

curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发]新更新事件\",
					\"text\": \"###[开发]开始构建${SDK}包 \n \"
				}
			}"
SDK="${SDK}"
if [ ${SDK} == 'default' ]; then
	BUILD_SYMBOLS="CHANNEL_SOULBATTLE"
elif [ ${SDK} == 'huawei' ]; then
	SDKTag=1
elif [ ${SDK} == 'oppo' ]; then
	SDKTag=2
elif [ ${SDK} == 'vivo' ]; then
	SDKTag=3
elif [ ${SDK} == 'xiaomi' ]; then
	SDKTag=4	
elif [ ${SDK} == 'taptap' ]; then
	SDKTag=5
elif [ ${SDK} == 'hykb' ]; then
	SDKTag=6
elif [ ${SDK} == 'tt' ]; then
	SDKTag=7
fi

#SDK TAG
echo -n ${SDKTag} > ${UNITY3D_SDK_TAG_PATH}
#Server TAG
echo -n ${TAG} > ${UNITY3D_SERVER_TAG_PATH}

if [ -f "${UNITY3D_BUNDLE_VERSION_PATH}" ]
then
	#读取之前打打包文件
	for cvs in `cat ${UNITY3D_BUNDLE_VERSION_PATH}`
	do
	  mainVersion="$(cut -d'|' -f1 <<<"${cvs}")"
	  mainSubVersion="$(cut -d'|' -f2 <<<"${cvs}")"
	  mainVersionCode="$(cut -d'|' -f3 <<<"${cvs}")"
	done
fi

mainSubVersion=$(expr "${mainSubVersion} + 0.1"|bc)
mainVersionCode=$(expr ${mainVersionCode} + 1)

echo -n "${BUILD_SYMBOLS}|${mainVersion}.${mainSubVersion}|${mainVersionCode}|${BUNDLE_ID}|${GAME_NAME}|${UNITY3D_CHANNEL}">${UNITY_CHANNEL_FILE_PATH}

if [ ! -d "${UNITY_STREAMASSET_PATH}" ]
then
	mkdir ${UNITY_STREAMASSET_PATH}
fi

if [ ! -d "${UNITY_STREAMASSET_PATH}/Android" ]
then
	mkdir ${UNITY_STREAMASSET_PATH}/Android
fi

if [ -f "${UNITY3D_PACKAGE_VERSION_PATH}" ]
then
	#读取之前打打包文件
	for cvs in `cat ${UNITY3D_PACKAGE_VERSION_PATH}`
	do
	  cv="$(cut -d'.' -f3 <<<"${cvs}")"
	  rv="$(cut -d'.' -f4 <<<"${cvs}")"
	done
fi

echo -n "${UNITY3D_CHANNEL}.AH.${cv}.${rv}" > ${UNITY_STREAMASSET_PATH}/Android/clientVersion.txt
cp ${UNITY_STREAMASSET_PATH}/Android/clientVersion.txt ${UNITY3D_PROJECT_PATH}/Assets/Resources/clientVersion.txt
#获取当前hash
hash=$(git rev-parse HEAD)

# cd ${UNITY3D_PROJECT_PATH}/Tools
# chmod a+x ToLuacOSX.sh
# chmod a+x luac

# ./ToLuacOSX.sh

#开始执行打包当前资源的方法
${UNITY3D_EXE_PATH} -quit -batchmode -nographics -nolog -executeMethod ${UNITY3D_BUILD_METHOD} -projectPath ${UNITY3D_PROJECT_PATH} -logFile -
echo "Build Pack Done"

UNITY_EXIT_CODE=$?

if [ $UNITY_EXIT_CODE -eq 0 ]; then
  echo "Run succeeded, no failures occurred";
else
  echo "Unexpected exit code $UNITY_EXIT_CODE";
  curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发]新更新事件\",
					\"text\": \"###[开发]构建${SDK}包失败 出现编译错误 代码[$UNITY_EXIT_CODE]\n \"
				}
			}"
	exit 0
fi



if [ -f "${UNITY3D_PROJECT_PATH}/Builds/Android/godsquest.apk" ]
then
	echo "build success"
else
	  curl ${DINGDING_ROBOT_ADDR} \
		-H 'Content-Type: application/json' \
		-d "{\"msgtype\": \"markdown\", 
			\"markdown\": {
				\"title\":\"[开发]新更新事件\",
					\"text\": \"###[开发]构建${SDK}包失败 无法定位包体位置 \n \"
				}
			}"
	exit 0
fi

cd ${UNITY3D_PROJECT_PATH}/Builds/Android

#${ZIP_COMMAND} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update.zip ${rv1}

#size="$(du -k ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update.zip)"


#echo ${size}>${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/info.txt
timeStamp="$(date +%s)"

mv godsquest.apk godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.apk 

${UNITY3D_IN_SYNC_CMD} ${UNITY3D_PROJECT_PATH}/Builds/Android/godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.apk --prefix Android/Packages/

if [ ! -d "${RES_PATH}VersionPath" ]
then
	mkdir ${RES_PATH}VersionPath
fi

if [ ! -d "${RES_PATH}VersionPath/${SDK}" ]
then
	mkdir ${RES_PATH}VersionPath/${SDK}
fi


echo -n "${mainVersion}|${mainSubVersion}|${mainVersionCode}">${UNITY3D_BUNDLE_VERSION_PATH}

rm -r godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.apk

qrencode -o godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.png -t png ${UNITY_DOWNLOAD_LINK}godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.apk

${UNITY3D_IN_SYNC_CMD} ${UNITY3D_PROJECT_PATH}/Builds/Android/godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.png --prefix Android/Packages/

rm -r ${UNITY3D_PROJECT_PATH}/Builds/Android/godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.png
#提交国内资源
# echo ${UNITY3D_IN_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}/update.zip --prefix ${UNITY3D_IN_PATH}/Android/
#提交国外资源
# echo ${UNITY3D_OUT_SYNC_CMD} ${UNTIY3D_PACKAGE_RES_PATH}/Android/${rv1}.zip --prefix ${UNITY3D_OUT_PATH}/Android/

curl ${DINGDING_ROBOT_ADDR} \
   -H 'Content-Type: application/json' \
   -d "{\"msgtype\": \"markdown\", 
       \"markdown\": {
          \"title\":\"[开发]新更新事件\",
            \"text\": \"###[开发] 构建${SDK}版本成功 \n 
			![screenshot](${UNITY_DOWNLOAD_LINK}godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.png)\n
			[点击下载](${UNITY_DOWNLOAD_LINK}godsquest_${SDK}_${UNITY3D_CHANNEL}_${timeStamp}.apk) \n 
			Version: ${mainVersion}.${mainSubVersion} \n 
			Bundle Version Code: ${mainVersionCode}  
			当前版本: ${cv}.${rv} \n 
			当前Tag: ${TAG} \"
        }
      }"

exit 0
