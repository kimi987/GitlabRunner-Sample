package main

import (
	_ "dingTalkRobotGJ/routes"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
