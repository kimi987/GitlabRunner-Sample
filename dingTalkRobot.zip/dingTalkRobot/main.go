package main

import (
	_ "dingTalkRobot/routes"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
